/*
The transform() function should accept data as input and transform it

The contents of data folder is fetched from `input.js` file

The function has to transform the data and generate as per the structure given in `expected-output.js`.

The expected-output data is used to render it on the browser using the code provided in `board-renderer.js` file.

The function should return error message
"Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!"
if the data is not an object and / or does not contain boards, lists, cards and comments as its array properties

DO NOT MODIFY THE CODE IN OTHER FILES AS IT WILL IMPACT THE TEST OUTCOME AND BROWSER OUTPUT.

*/
export function transform(data) {
  // Check if data is an object with the required properties
  if (
    typeof data === "object" &&
    Array.isArray(data.boards) &&
    data.boards.length > 0 &&
    Array.isArray(data.lists) &&
    data.lists.length > 0 &&
    Array.isArray(data.cards) &&
    data.cards.length > 0 &&
    Array.isArray(data.comments)
  ) {
    const transformedData = {
      boardId: data.boards[0].boardId,
      boardTitle: data.boards[0].boardTitle,
      lists: data.lists.map((list) => ({
        listId: list.listId,
        listTitle: list.listTitle,
        cards: data.cards
          .filter((card) => card.listId === list.listId)
          .map((card) => ({
            cardId: card.cardId,
            cardTitle: card.cardTitle,
            comments: data.comments.filter(
              (comment) => comment.cardId === card.cardId
            ).length,
          })),
      })),
    };

    return transformedData;
  } else {
    // Return an error message if the input data is invalid
    return "Invalid Input Type, Input Type Must Be An Object with Array Type Boards, Lists, Cards and Comments Properties !!";
  }
}

const config = {
  transform: {},
};

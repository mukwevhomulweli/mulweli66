const output = {
  "boards": [
    {
      "boardId":"123",
      "boardTitle":"First Sample Board",
      "members":[
        {
          "memberId":"456",
          "memberName":"xyz"
        }
      ],
      "lists": [
        {
          "listId":"987",
          "listTitle":"First List",
          "cards":[
            {
              "cardId":"102",
              "cardTitle":"First Card",
              "comments":[
                {
                  "commentId":"918",
                  "commentText":"First Comment"
                }
              ]
            }
          ]
        }
      ]
    }
  ]
}